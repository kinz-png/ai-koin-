plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "id.eltiy.micinai"
    compileSdk = 35
    defaultConfig { applicationId = "id.eltiy.micinai"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "0.4.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
